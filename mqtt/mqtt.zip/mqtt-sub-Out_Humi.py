#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from setenv import user, password
import paho.mqtt.client as mqtt
import time
import redis

MQTTHOST = "hairdresser.cloudmqtt.com"
RedisHost = "192.168.0.15"
Topic = "Out_Humi"

r = redis.Redis(host=RedisHost, port='6379')

def on_message(client, userdata, message):
    m = str(message.payload.decode("utf-8"))
    print("message received " + m)
    r.set('Out_Humi',m)
#    print("message topic=",message.topic)
#    print("message qos=",message.qos)
#    print("message retain flag=",message.retain)


# 3.1.1�p��Client���쐬���܂�
client = mqtt.Client(protocol=mqtt.MQTTv311)
# ���[�U�[���ƃp�X���[�h��ݒ肵�܂�
client.username_pw_set(user, password)

# �ڑ����܂�
client.connect(MQTTHOST, port=17817, keepalive=60)

client.loop_start() #start the loop

while True:
    client.subscribe(Topic)
    time.sleep(2) # wait

client.loop_stop() #stop the loop

